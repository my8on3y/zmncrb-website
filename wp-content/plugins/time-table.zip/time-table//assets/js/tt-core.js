/*-----------------------------
* Build Your Plugin JS / jQuery
-----------------------------*/
/*
Jquery Ready!
*/
jQuery(document).ready(function($){
    "use strict";
    /*
    Add basic front-end page scripts here
    */
    
    
    // End basic front-end scripts here
});